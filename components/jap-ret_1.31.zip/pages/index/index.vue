<template>
	<view>		
		<!-- 自定义导航栏 -->
		<view style="height: 70rpx;position: fixed;background-color: #FFFFFF;z-index: 10;width: 100%;">
			
		</view>
		<!-- 组件的上面要预留一个可以隐藏的空间 -->	
	   <!--组件属性-> widthImg刷新图宽 heightRh下拉刷新整体高度(因对应导航栏高度) msgShow(是否显示文字) image(图片路径) -->
		<refresh @down="end" :msgShow="false" >
			<slot>
				<!-- 你的业务 -->
				<view style="margin-top: 15rpx;height: 2060rpx;background-color: #f8f8f8;">
					
				</view>
			</slot>			
		</refresh>

	</view>
</template>

<script>
	// 判断页面是否触顶 ,0触顶,1没有触顶
	var top=0
	import refresh  from '@/components/refresh/refresh.vue'
	export default {
		components: {refresh},
		onPageScroll(e) {
			if(e.scrollTop<1){
				top=0
				uni.$emit("reMsg",0)
			}else{
				if(top!=1){
					top=1
					uni.$emit("reMsg",1)
				}				
			}
		},
		onLoad() {

		},
		data() {
			return {
			}
		},
		methods: {
			end(i){
				console.log(i)
				// 这里写刷新业务
				setTimeout(()=>{
					// 收回下拉刷新
					uni.$emit("reMsg",-1)
				},2000)
			}
		}
	}
</script>




<style>

</style>
